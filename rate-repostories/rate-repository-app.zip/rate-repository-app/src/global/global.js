export const ip = '192.168.1.81';

export const url = `http://${ip}:5000/api`;