import { FlatList, StyleSheet, View } from 'react-native';
import RepositoryItem from './RepositoryItem';
import useRepositories from '../hooks/useRepositories';
import theme from '../theme';

export default function RepositoryList() {
  const { repositories } = useRepositories();

  return (
    <FlatList 
      data={repositories}
      renderItem={({ item }) => (
        <RepositoryItem repository={item} />
      )}
      ItemSeparatorComponent={() => <View style={styles.separator} />}
    />
  );
}

const styles = StyleSheet.create({
  separator: {
    borderBottomColor: theme.colors.textSecondary,
    borderWidth: 1,
    marginVertical: 15
  }
});