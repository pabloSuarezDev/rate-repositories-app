import { TextInput, StyleSheet } from 'react-native'
import theme from '../theme';

export default function StyledTextInput({ style = {}, error, ...restOfProps }) {
  const inputStyle = [
    styles.input,
    style,
    error && styles.error
  ]

  return <TextInput style={inputStyle} {...restOfProps} />;
}

const styles = StyleSheet.create({
  input: {
    borderRadius: 5,
    borderWidth: 1,
    borderColor: theme.colors.textSecondary,
    paddingHorizontal: 20,
    paddingVertical: 10,
    marginBottom: 5,
    fontSize: theme.fontSizes.body,
    fontFamily: theme.fonts.main,
    fontWeight: theme.fontWeights.normal
  },
  error: {
    borderColor: theme.colors.red
  }
});