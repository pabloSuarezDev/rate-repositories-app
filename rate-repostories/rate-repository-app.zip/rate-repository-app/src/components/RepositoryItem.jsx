import { View, StyleSheet } from 'react-native';
import RepositoryStats from './RepositoryStats';
import RepositoryItemHeader from './RepositoryItemHeader';

export default function RepositoryItem({ repository }) {
  return (
    <View key={repository?.id} style={styles.repositoryItem}>
      <RepositoryItemHeader repository={repository} />
      <RepositoryStats stats={repository} />
    </View>
  );
}

const styles = StyleSheet.create({
  repositoryItem: {
    padding: 20,
    paddingVertical: 5
  }
});