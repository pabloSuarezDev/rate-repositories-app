import { View, Image, StyleSheet, Platform } from 'react-native';
import theme from '../theme';
import StyledText from './StyledText';

export default function RepositoryItemHeader({ repository }) {
  return (
    <View style={styles.itemHeaderContainer}>
      <View>
        <Image style={styles.image} source={{ uri: repository?.ownerAvatarUrl }} />
      </View>
      <View style={styles.repoInfoContainer}>
        <StyledText fontSize="subheading" fontWeight="bold">{repository?.fullName}</StyledText>
        <StyledText >{repository?.description}</StyledText>
        <StyledText  style={styles.language}>{repository?.language}</StyledText>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  itemHeaderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
    paddingBottom: 2
  },
  image: {
    width: 48,
    height: 48,
    borderRadius: 4
  },
  //! FLEX 1 CAN BE USE LIKE FLEX-WRAP: WRAP; TOO
  repoInfoContainer: { flex: 1 },
  language: {
    padding: 4,
    color: theme.colors.white,
    backgroundColor: Platform.select({
      android: theme.colors.primary,
      ios: theme.colors.orange,
      default: theme.colors.night
    }),
    alignSelf: 'flex-start',
    marginVertical: 5,
    borderRadius: 4
  }
});