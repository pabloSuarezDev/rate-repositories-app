import { StyleSheet } from 'react-native';
import { useField } from 'formik';
import StyledTextInput from './StyledTextInput';
import StyledText from './StyledText';
import theme from '../theme';

export default function FormikInputValue({ name, ...props }) {
  const [field, meta, helpers] = useField(name);

  return(
    <>
      <StyledTextInput 
        error={meta.error}
        value={field.value}
        onChangeText={value => helpers.setValue(value)}
        {...props}
      />
      {
        meta.error && 
          <StyledText style={styles.error}>{meta.error}</StyledText>
      }
    </>
  );
}

const styles = StyleSheet.create({
  error: {
    color: theme.colors.red,
    fontSize: theme.fontSizes.body,
    marginBottom: 20,
    marginTop: -5
  }
});