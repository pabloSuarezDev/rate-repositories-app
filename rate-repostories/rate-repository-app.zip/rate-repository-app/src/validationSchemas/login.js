import { object, string } from 'yup';

export const loginValidationSchema = object().shape({
  email: 
    string()
    .email()
    .required('Email is required'),

  password: 
    string()
    .min(5, 'Too short!')
    .max(1000, 'Too long!')
    .required('Password is required')
});