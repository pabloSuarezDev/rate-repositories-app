import RepositoryList from '../components/RepositoryList';

export default function MainScreen() {
  return <RepositoryList />;
}