import { View, Button, StyleSheet } from 'react-native';
import { Formik } from 'formik';
import { loginValidationSchema } from '../validationSchemas/login';
import FormikInputValue from '../components/FormikInputValue';
import StyledText from '../components/StyledText';

const initialValues = {
  email: '',
  password: ''
};

export default function LogInForm() {
  return (
    <Formik 
      validationSchema={loginValidationSchema} 
      initialValues={initialValues} 
      onSubmit={values => console.log(values)}
    >
      {({ handleSubmit }) => {
        return(
          <View style={styles.form}>
            <StyledText align="center" color="primary" fontSize="subheading">
              Sing In!
            </StyledText>
            <FormikInputValue 
              name="email"
              placeholder="E-mail"
            />
            <FormikInputValue
              name="password"
              placeholder="Password"
              secureTextEntry
            />
            <Button 
              title='Log In' 
              onPress={handleSubmit}
            />
          </View>
        );
      }}
    </Formik>
  );
}

const styles = StyleSheet.create({
  form: {
    flex: 1,
    alignContent: 'center',
    justifyContent: 'center',
    gap: 10,
    margin: 16
  }
});