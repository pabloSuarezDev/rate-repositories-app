import MainScreen from './MainScreen';
import LogInScreen from './LogInScreen';

const screens = [
  {
    name: 'Repositories',
    component: MainScreen,
    icon: 'home'
  },
  {
    name: 'Sign In',
    component: LogInScreen,
    icon: 'log-in'
  }
];

export default screens;