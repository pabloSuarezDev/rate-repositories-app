import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import screens from '../screens/screens';
import Ionicons from '@expo/vector-icons/Ionicons';

const TabTop = createMaterialTopTabNavigator();
const TabBottom = createBottomTabNavigator();

export function AndroidNavigator() {
  return (
    <TabTop.Navigator>
      {screens && screens.map(screen => (
        <TabTop.Screen
          key={screen?.name}
          name={screen?.name}
          component={screen?.component}
          options={{ headerShown: false }}
        />
      ))}
    </TabTop.Navigator>
  );
}

export function IOSNavigator() {
  return (
    <TabBottom.Navigator>
      {screens && screens.map(screen => (
        <TabBottom.Screen
          key={screen?.name}
          name={screen?.name}
          component={screen?.component}
          options={{
            tabBarIcon: ({ focused, color, size }) => (
              <Ionicons
                name={focused ? screen?.icon : `${screen?.icon}-outline`}
                size={size}
                color={color}
              />
            )
          }}
        />
      ))}
    </TabBottom.Navigator>
  );
}