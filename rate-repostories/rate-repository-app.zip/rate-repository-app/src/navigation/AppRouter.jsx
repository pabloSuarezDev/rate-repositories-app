import { Platform } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { AndroidNavigator, IOSNavigator } from './Navigators';

const Navitagor = Platform.select({
  android: () => <AndroidNavigator />,
  ios: () => <IOSNavigator />,
  default: () => <AndroidNavigator />
});

export default function AppRouter() {
  return (
    <NavigationContainer>
      <Navitagor />
    </NavigationContainer>
  );
};