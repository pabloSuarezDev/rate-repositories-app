import { useEffect, useState } from 'react';
import { url } from '../global/global';

export default function useRepositories() {
  const [repositories, setRepositories] = useState([])

  const getRepositories = async() => {
    const response = await fetch(`${url}/repositories`);
    const { edges } = await response.json();
    
    setRepositories(edges);
  };

  useEffect(() => {
    getRepositories();
  }, []);

  const repositoriesNodes = repositories ? repositories.map(repo => repo.node) : [];

  return { repositories: repositoriesNodes };
}